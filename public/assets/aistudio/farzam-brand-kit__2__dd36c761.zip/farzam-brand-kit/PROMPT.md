# ROLE

You are a senior creative director, brand designer and creative developer in one person, with the taste level of Awwwards "Site of the Year" winners. You will design AND build a landing website that makes people stop scrolling and say "what is this?!". Mediocre, templated, "clean SaaS" output is a failure. The goal is bold, strange, memorable, and still fast, accessible and usable on a phone.

This is a CLEAN-SLATE project. There is no existing website, no design system, no code base and no screenshots. Do not look for any and do not ask for any. You create everything from the brand assets below.

# WHAT IS IN THIS ZIP (read all of it before thinking about design)

```
PROMPT.md                  this file
brand/
  logo.svg                 the real logo (never redraw, recolour wildly or distort it)
  typography.svg           the real wordmark / typography lockup
  COLORS.md                the three core brand colours
  fonts/woff2              Peyda weights 300-900 (use these on the web)
  fonts/ttf                Peyda full family incl. thin/extralight (source files)
content/
  farzam-features.md       the source of truth for what we offer (software + hardware)
```

Read brand/COLORS.md, brand/logo.svg, brand/typography.svg and content/farzam-features.md fully first.

# THE BUSINESS (what the site must express)

We are a Persian-language fleet intelligence company. We do three things, and the site must make them feel like ONE connected system:

1. HARDWARE: GPS trackers (IMEI/ID + SIM), ignition/power input, motion/speed telemetry, voltage, and, depending on the model, temperature and fuel sensing.
2. SOFTWARE (MyFarzam): live map, dashboard KPIs, device inventory, groups, geofences, notifications (alerts / maintenance / system), and 9 reports (Route, Trip, Stop, Daily, Performance, Event, Geofence, Heatmap, Temperature) with Excel export. Personal and organisational use (organisations get groups, multi-device reports, comparison, heatmap).
3. CUSTOMISATION: we tailor hardware and software integrations to an organisation's needs.

Core idea to translate into visuals: "what we do becomes the visual identity". Every capability gets its own visual metaphor, motion and material, all living in ONE shared world. Use content/farzam-features.md as the only source of truth. Do not invent features, clients, statistics or testimonials.

# PHASE 0: THINK BEFORE YOU BUILD (mandatory, do this first)

Do not start coding. First write `DIRECTION.md` containing:

1. BRAND READING. Study the logo geometry (curves, corner radii, stroke weight, negative space), the wordmark and the character of Peyda. State what visual motifs can be derived from them (shapes, corner language, motion feeling) and use those motifs across the site so everything feels born from the logo.
2. DESIGN FOUNDATIONS you create yourself, as one single source of truth (CSS variables / tokens file):
   - an extended palette derived ONLY from the three core colours (Vibrant Orange #FF742E, Deep Navy #102333, Warm Beige #E8DECD): tints/shades, neutrals, a small status palette (moving, stopped, alert, cold-chain, offline), each role with a tested contrast pair (WCAG AA >= 4.5:1 for text)
   - type scale with Peyda, spacing scale, radii, elevation/shadow system, and a motion language (durations, easings, what "the signal" feels like when it moves)
3. THREE DISTINCT, genuinely different art directions for a "path / journey" site. For each: a name, a 3-sentence concept, the scroll mechanic, the 3D/material language, and its risks. Make them bold. Starting points (invent better ones): one continuous signal thread that the camera rides through a 3D world (camera fly-through); a terrain/topography world where reports become landscapes; a scale-zoom journey from one device to a city to a boardroom; a logo that is built from fragments as you scroll; a hardware-to-dashboard exploded-view narrative.
4. CHOOSE ONE and justify it against: wow factor, fit with our business, performance on mid-range phones, Persian/RTL compatibility. Pick the boldest one that can still ship reliably. Do not ask me to choose; decide like a creative director.
5. A chapter-by-chapter STORYBOARD with, per chapter: the question the customer is asking, the visual metaphor, the interaction, and the mobile adaptation.
6. A short TECH PLAN: stack, libraries and why, scene/asset budget, fallbacks.

Then build the chosen direction.

# CREATIVE REQUIREMENTS

## The spine: the living signal path
The site is built around ONE living orange "signal" line that connects everything and carries the story from chapter to chapter, like a route on a map that becomes the narrative. Make it far more than a decorative line: depth, physicality, surprise. It reacts to scroll, pointer and touch; it passes through objects; it changes state (travelling, stopped, alert, cold-chain); it drives the camera or the layout. The signal is the main character. The result must feel bold, strange and unforgettable, while staying clear about what we sell.

## Logo and brand
Use the real logo as a signature moment (for example it forms, breaks apart or is assembled by the signal at a key scroll point). Never redraw or distort it. Use Peyda at its real weights.

## Colour discipline (important)
- One dominant ground, one dark "light-giver", and orange ONLY for "live things": the signal, the active state, the single primary action. Card outlines, labels and secondary buttons use neutrals. If everything is orange, nothing is important.
- Use light/dark as storytelling: dark chapters = live control and real time; light chapters = organisation, reports, proof. The signal line crosses the boundaries as a bridge. The transitions between dark and light must be designed and intentional (no muddy gradient fades, no sections that feel like they belong to another site).
- Build depth in light sections with 2-3 beige tones plus soft shadows, not borders. Avoid flat beige-on-beige.
- Stay inside the derived palette; no stray greens or blues.

## Chapter structure (adapt and enrich, keep the logic)
1. HERO: very few words. Persian text on the right, the animation NOT behind the text. Pointer and scroll interactive, no play/pause controls. A jaw-dropping first screen.
2. HARDWARE: the physical tracker as a beautiful 3D object. Show the sensors it can carry (GPS, ignition, voltage, temperature, fuel) as layers or exploded parts that light up the signal.
3. CONNECTIVITY: SIM + IMEI -> the moment a device "comes alive" on the map (registration as an event).
4. LIVE CONTROL: map, geofences, alerts. Geofence as a glass dome/boundary the signal passes through; alerts as beacons on a timeline.
5. REPORTS (the most important chapter for organisations): each report is "the question a manager asks". Give each a unique metaphor and micro-interaction, all in the same world:
   - Route = "Where did it go?" -> the signal thread drawing the path
   - Trip = "How many journeys?" -> beads/chapters on the thread
   - Stop = "Where did it wait?" -> a ring under a pin that grows with dwell time
   - Daily = "How did the shift go?" -> a clock-like ring filling with ignition time
   - Performance = "Who did best?" -> lanes/columns racing side by side
   - Geofence = "Was it inside the site?" -> inside/outside states of a boundary
   - Event = "What happened?" -> flare markers on a timeline
   - Heatmap = "Where is traffic concentrated?" -> a glowing relief/terrain
   - Temperature = "Did the cargo stay safe?" -> frosted-glass/ice material changing with temperature
   Add the organisational value lines: accountability, cost control, safety and compliance, and "evidence" (Excel export turns a report into a document).
6. PERSONAL vs ORGANISATION: a clear, delightful way to show groups, multi-device comparison and fleet-level views.
7. CUSTOMISATION: our tailored hardware/software integrations, shown as the system "plugging into" a customer's world.
8. PRODUCT UI: see next section.
9. FINAL CTA: a memorable ending that closes the signal path with a clear action.

## Product UI (no screenshots exist)
DESIGN the product interface yourself as beautiful, believable UI built in code (HTML/CSS/SVG/WebGL), floating in 3D frames or integrated into the scenes: dashboard KPI cards, charts, report tables, a geofence drawer, an alert feed, a heatmap. Base the structure on content/farzam-features.md (for example Dashboard: total / powered-on / moving / located devices plus speed, distance and stop charts; Performance: a multi-device comparison table). Use ONLY synthetic demo data: invented fleet names, Persian digits, fake plates and numbers; no real customer, phone, address or coordinates. Illustrative numbers must be clearly demo.

## Copy
Persian, short, outcome-driven, confident. Headlines answer a manager's question or promise a result; no feature lists. Do not claim fuel/temperature capabilities as universal: phrase them as "with compatible sensors".

# TECHNICAL REQUIREMENTS

## Stack and quality of code
- Vite + React + Three.js (react-three-fiber is fine). Add GSAP/ScrollTrigger, Lenis or other libraries only if they clearly earn their place; pin exact versions.
- `lang="fa"` `dir="rtl"`. Use CSS logical properties (inline-start/end) everywhere. Persian digits with tabular alignment.
- All colours, spacing, radii, shadows and motion values come from your tokens file. No scattered raw colour values in components.
- Fonts: Peyda woff2 from brand/fonts, `font-display: swap`, preload the critical weights.
- Clean structure, a README explaining how to run and build, and a production build that passes without warnings that matter.

## Responsive (very important, first-class requirement)
- Design mobile-first and treat the phone as the PRIMARY experience, not a degraded one. Test at 360, 390, 768, 1024, 1280, 1440 widths and short landscape phones.
- Use sensible breakpoints (for example 640 / 1024 / 1280).
- On mobile, re-compose each chapter instead of shrinking it: different layout, simpler 3D, touch-driven interactions (drag/tilt) instead of hover. No horizontal scroll. Tap targets >= 44px. Use dvh/svh and safe-area insets.

## Performance and robustness
- Target smooth 60fps on mid-range phones, LCP < 2.5s on 4G, minimal layout shift. Lazy-load every WebGL scene (React.lazy + IntersectionObserver), cap pixel ratio (<= 1.5 on mobile), dispose GPU resources, pause off-screen scenes.
- Graceful fallbacks: no WebGL -> a static CSS/SVG version that still looks great; `prefers-reduced-motion` -> a stable, fully readable final state with no autoplay loops.
- NO empty states or placeholders on the final page ("waiting for signal..." or blank cards must never appear). Every card renders real content on load.
- Accessibility: semantic landmarks, skip link, visible focus states, meaningful aria-labels, keyboard operable, WCAG AA contrast on all text.

# PROCESS AND QUALITY BAR

1. Write DIRECTION.md (Phase 0).
2. Build the site chapter by chapter.
3. Verify like a skeptic: run the build, open the site at all the widths above, take screenshots, check contrast, and fix visible problems (overlaps, clipped text, broken RTL, jank, empty cards) BEFORE reporting.
4. Push it further than feels safe. If a section looks like any other SaaS landing page, redo it.

# DELIVERABLES

- The working site project (landing page), ready to run.
- `DIRECTION.md` (brand reading, foundations, three directions, the chosen one, storyboard, tech plan).
- A final report: what you built per chapter, libraries added and why, performance numbers, the responsive and fallback strategy, anything you could not verify, and the screenshots you used to check your work.
